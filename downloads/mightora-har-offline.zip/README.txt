Mightora HAR Analyser — Offline edition
=======================================

1. Extract this ZIP archive.
2. Open har-analyser.html in a modern browser (Chrome, Edge or Firefox).
3. Choose a .har file from your computer. No application install or network is required.
4. Review any sanitised JSON export carefully before sharing.

All JavaScript, CSS and Mightora logo assets are embedded into the HTML.
A restrictive Content Security Policy blocks external connections and assets.
No remote scripts, telemetry or uploads are used in the offline edition.
The original HAR may contain confidential tokens, cookies, addresses, and bodies.
Exported reports may retain identifying hostname and URL path data.

Project: https://github.com/mightora/har
Licence: MIT (see LICENSE.txt)
